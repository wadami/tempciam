#!/bin/bash

echo "setting port forwards for PingConsole"
kubectl port-forward service/pingdataconsole 8443 &
echo "setting port forwards for PingDirectory"
kubectl port-forward service/pingdirectory 1443:443 1389:389 1636:636 &
